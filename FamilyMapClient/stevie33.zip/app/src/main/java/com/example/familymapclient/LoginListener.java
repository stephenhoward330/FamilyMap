package com.example.familymapclient;

interface LoginListener {
    void onLogin(); // pass any parameter in your onCallBack which you want to return
}