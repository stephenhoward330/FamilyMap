package Response;

/** Response class for the other responses and error response to inherit from */
public class Response {
    /** message from the error response */
    private String message;

    public String getMessage() {
        return message;
    }
}